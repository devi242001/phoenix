package com.example.map;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ma extends AppCompatActivity {
    Button veronica,rules,receipe,exit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ma);
        veronica = findViewById(R.id.veronica);
        rules = findViewById(R.id.rules);
        receipe = findViewById(R.id.receipe);
        exit = findViewById(R.id.exit);
        veronica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ma.this,matchinggame1.class);
                startActivity(intent);

            }

        });
        rules.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ma.this,puzzle1.class);
                startActivity(intent);

            }

        });
        receipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ma.this,ab.class);
                startActivity(intent);

            }

        });
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ma.this,map.class);
                startActivity(intent);

            }

        });
    }
}






