package com.example.map;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class guj extends AppCompatActivity {
    Button veronica,rules,receipe,exit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guj);
        veronica = findViewById(R.id.veronica);
        rules = findViewById(R.id.rules);
        receipe = findViewById(R.id.receipe);
        exit = findViewById(R.id.exit);
        veronica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(guj.this,matchinggame.class);
                startActivity(intent);

            }

        });
        rules.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(guj.this,puzzle.class);
                startActivity(intent);

            }

        });
        receipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(guj.this,h.class);
                startActivity(intent);

            }

        });
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(guj.this,map.class);
                startActivity(intent);

            }

        });
    }
}






