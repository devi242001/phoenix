package com.example.map;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class user {
    public String  fullName , age , email;

    public user(){

    }
    public  user(String fullName, String age ,String email) {
        this.fullName = fullName;
        this.age = age;
        this.email = email;
    }
}