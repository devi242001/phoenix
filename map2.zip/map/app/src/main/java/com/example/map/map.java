package com.example.map;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class map extends AppCompatActivity {
    ImageView imageview;
    TextView textView,textView1,textView2,textView3,textview4;
    ScaleGestureDetector scaleGestureDetector;
    float scaleFactor = 1.0f;
    private MotionEvent event;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);




        textView = (TextView) findViewById(R.id.textview);
        textView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(map.this, tn.class);
                startActivity(intent);

            }
        });

        textView1 = (TextView) findViewById(R.id.textview1);
        textView1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(map.this, ma.class);
                startActivity(intent);

            }
        });
        textView2 = (TextView) findViewById(R.id.textview2);
        textView2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(map.this, guj.class);
                startActivity(intent);

            }
        });

        textView3 = (TextView) findViewById(R.id.textview3);
        textView3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(map.this, west.class);
                startActivity(intent);

            }
        });

        textview4 = (TextView) findViewById(R.id.textview4);
        textview4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(map.this, del.class);
                startActivity(intent);
            }
        });
    }
}

/*

            imageview = findViewById(R.id.indiamap);
            scaleGestureDetector = new ScaleGestureDetector(this, new scaleListener());
        }

        //detect touch on the entire view
        public boolean onTouchEvent (MotionEvent event){
            return scaleGestureDetector.onTouchEvent(event);
        }
        //setup the scale factor and apply to the image
        private class scaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {

            public boolean onScale(ScaleGestureDetector detector) {
                scaleFactor *= scaleGestureDetector.getScaleFactor();
                imageview.setScaleX(scaleFactor);
                imageview.setScaleY(scaleFactor);
                return true;
            }
        }
    }
*/








