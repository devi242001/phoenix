package com.example.map;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class del extends AppCompatActivity {
    Button veronica,rules,receipe,exit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_del);
        veronica = findViewById(R.id.veronica);
        rules = findViewById(R.id.rules);
        receipe = findViewById(R.id.receipe);
        exit = findViewById(R.id.exit);
        veronica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(del.this,matchinggame2.class);
                startActivity(intent);

            }

        });
        rules.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(del.this,puzzle2.class);
                startActivity(intent);

            }

        });
        receipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(del.this,award.class);
                startActivity(intent);

            }

        });
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(del.this,map.class);
                startActivity(intent);

            }

        });
    }
}






